#include <iostream.h>
#include <conio.h>

int main ()
{
	int var1, var2, var3;
	char karakter;
	var1=10;
	var2=5;
	var3=var1+var2;
	karakter='D';
	cout<<"Nilai var3 = "<<var3<<"\n";
	cout<<"Nilai karakter = "<<karakter;
}