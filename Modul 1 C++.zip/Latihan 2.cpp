#include<iostream>

using namespace std;

int main()
{
	float phi=3.14;
	float r,luas;
	
	cout<<"menghitung luas lingkaran \n";
	cout<<"masukan jari jari:";
	cin>>r;
	luas=phi*r*r;
	cout<<"hasil luas lingkaran:";
	cout<<luas;
}