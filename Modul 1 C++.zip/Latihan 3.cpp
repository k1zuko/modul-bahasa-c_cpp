#include <iostream>

using namespace std;

int main()
{
	float Alas, Tinggi, Luas_Segitiga;
	
	cout<<"Masukkan Nilai Alas Segitiga : ";
	cin>>Alas;
	cout<<"Masukkan Nilai Tinggi Segitiga : ";
	cin>>Tinggi;
	Luas_Segitiga=0.5*Alas*Tinggi;
	cout<<"Nilai Luas Segitiga adalah : "<<Luas_Segitiga<<endl;
}