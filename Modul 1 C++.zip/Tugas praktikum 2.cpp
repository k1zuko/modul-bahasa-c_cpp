#include <stdio.h>

int main()
{
	long int OL;
	/*Sejumlah angka dari ketinggian*/
	printf("Masukkan panjang : ");
	scanf("%ld",&OL);
	printf("Angka yang anda masukkan adalah %ld", OL);
}