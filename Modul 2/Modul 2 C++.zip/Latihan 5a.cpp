#include <iostream.h>

int main ()
{
	int p=255;
	
	cout<<"[p>=0 && p<=255] → "<<(p>=0 && p<=255)<<endl;
	cout<<"[p>=0 || p<=255] → "<<(p>=0 || p<=255)<<endl;
}