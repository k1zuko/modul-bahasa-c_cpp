#include <iostream>
using namespace std;

int main ()
{
	int a = 10;
	
	if (a < 20)
	{
		cout << "a kurang dari 20" <<endl;
	}
	cout << "nilai a adalah : " <<a<<endl;
	
	return 0;
}