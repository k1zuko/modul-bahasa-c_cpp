#include <iostream.h>
#include <conio.h>

int main ()
{
	cout << "Menampilkan bilangan bulat 1-10 \n";
	
	for (int a=1; a<=10; a++) {
		cout << a <<endl;
	}
	
	getch();
}